library(readr)
df <- read_csv("~/Desktop/sp8/organelle7.csv")
summary(df)
library(dplyr)
organelle7_df <- df %>% group_by(Reps, region_index, Time, Marker) %>% summarize(mean_fluor = mean(Norm_fluoro))
organelle7_df

write.csv(organelle7_df, file="~/Desktop/sp8/organelles7_df.csv")


library(ggplot2)
ggplot(organelle7_df) + 
  aes(Time, mean_fluor) + 
  geom_jitter(aes(colour = organelle7_df$region_index)) + 
  geom_smooth(aes(colour =organelle7_df$region_index), method = "glm")
#to remove tne grouping
organelle7_df$region_index <- as.factor(organelle7_df$region_index)
organelle7_df$Time <- factor(organelle7_df$Time, levels = c("0h", "4h", "8h", "24h"), ordered = TRUE)
organelle7_df$Marker <- factor(organelle7_df$Marker, levels = c("Scad2","Pex6","Sec7","Grh1", "Vac8","Rpl25","HDEL"), ordered = TRUE)
organelle7_df <- organelle7_df %>% mutate(time_c = as.numeric(stringr::str_replace(Time, "h", "")))


ggplot(organelle7_df) + 
  aes(Time, mean_fluor) + 
  geom_jitter(aes(colour = organelle7_df$region_index)) + 
  geom_smooth(aes(colour =organelle7_df$region_index), method = "glm") + 
  facet_grid(~organelle7_df$Marker)


#data replotted for a white background without grid lines
Compartment <- organelle7_df$region_index
ggplot(organelle7_df) + aes(time_c, mean_fluor) +
  geom_smooth(aes(colour = Compartment), method = "glm") + facet_wrap(~Marker, ncol=2)  +
  theme_bw() +
  theme(panel.grid.major=element_blank()) +
  theme(panel.grid.minor = element_blank()) + 
  theme(strip.text.x =element_text(size = 16, face="bold", colour="black")) + 
  theme(axis.title.y.left = element_text(size = 16, face="bold", colour="black", vjust = 1.3)) +
  theme(axis.text.x = element_text(size = 16, colour="black")) +
  theme(axis.text.y = element_text(size = 16, colour="black"))+
  scale_y_continuous(name= "Normalised GFP intensity") +
  scale_x_continuous(name="Time (hour)",  limit= c(0, 24), breaks=seq(0,24, by=4), labels=c(0, 4, 8, 12, 16, 20,24)) +
  theme(strip.background = element_rect(colour="black", fill="white")) +
  theme(axis.title.x.bottom = element_text(size = 16, face="bold", colour="black", vjust=0.8)) +
  theme(legend.title = element_text(size=16, face="bold")) +
  theme(legend.text = element_text(colour="black", size = 16)) +
  theme(legend.position = c(.8, .11)) 

ggsave("organelle7_df.tiff", dpi=900, height=297, width=210, units="mm")
